'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ChevronLeft, ChevronRight, Shuffle, RotateCcw } from 'lucide-react'

interface Flashcard {
  front: string
  back: string
}

const flashcards: Flashcard[] = [
  {
    front: "Why do governments intervene in trade?",
    back: "They intervene for political motives (jobs, security, influence, fairness), economic motives (infant industries, strategic trade, correcting market failures, currency misalignment), and cultural motives (protecting identity, media, education, language)."
  },
  {
    front: "Political motives for trade intervention",
    back: "Include protecting jobs, safeguarding national security, countering unfair trade practices, and using trade as a tool of diplomacy and influence."
  },
  {
    front: "Economic motives for trade intervention",
    back: "Include infant industry protection, strategic trade policy, correcting market failures, and addressing currency manipulation."
  },
  {
    front: "Cultural motives for trade intervention",
    back: "Protect national identity, domestic media industries, language, education, and cultural values from foreign dominance."
  },
  {
    front: "Export Subsidy",
    back: "Direct financial support to firms for export sales (e.g., agricultural support programs, Airbus subsidies)."
  },
  {
    front: "Export Credit Agency (ECA)",
    back: "A government institution providing financing and insurance for exporters to reduce risks in international sales."
  },
  {
    front: "Export Credit / Financing Programs",
    back: "Includes loans, loan guarantees, and insurance that help exporters compete abroad (e.g., U.S. EXIM Bank)."
  },
  {
    front: "Political Risk Insurance",
    back: "Government-backed insurance against losses from political instability, expropriation, or contract breaches abroad."
  },
  {
    front: "Foreign Trade Zone (FTZ)",
    back: "Designated area where imported goods can be stored, processed, or re-exported under favorable customs rules."
  },
  {
    front: "Special Economic Zone / Free Port",
    back: "Area with customs, tax, and regulatory benefits to encourage international trade and investment."
  },
  {
    front: "Trade Promotion Agencies",
    back: "Government bodies providing market research, trade missions, and training to help firms export."
  },
  {
    front: "Tariff",
    back: "A tax on imported goods, making them more expensive relative to domestic products."
  },
  {
    front: "Ad Valorem Tariff",
    back: "Tariff calculated as a percentage of the value of imported goods."
  },
  {
    front: "Specific Tariff",
    back: "Tariff assessed as a fixed amount per unit of imported goods (e.g., $1 per pound)."
  },
  {
    front: "Compound Tariff",
    back: "A mix of specific and ad valorem tariffs — protecting both quantity and value dimensions."
  },
  {
    front: "Import Quota",
    back: "Restriction on the quantity/value of imports allowed into a country during a period."
  },
  {
    front: "Tariff-Rate Quota (TRQ)",
    back: "Two-tier system: low tariff up to a quota; very high tariff on imports above the quota."
  },
  {
    front: "Voluntary Export Restraint (VER)",
    back: "Agreement where an exporter voluntarily limits shipments to avoid harsher restrictions."
  },
  {
    front: "Embargo",
    back: "A complete prohibition of trade with a country or in certain goods."
  },
  {
    front: "Trade Sanctions",
    back: "Restrictions to pressure a country, ranging from targeted sanctions (individuals/sectors) to secondary sanctions (third parties)."
  },
  {
    front: "Non-Tariff Barrier (NTB)",
    back: "Trade restriction other than tariffs — includes technical standards, licensing, and local content rules."
  },
  {
    front: "Local Content Requirement",
    back: "Rule requiring products to include a certain percentage of domestic inputs."
  },
  {
    front: "Technical Barriers to Trade",
    back: "Standards, testing, and certification requirements that can block imports."
  },
  {
    front: "GATT (General Agreement on Tariffs and Trade)",
    back: "Established in 1947 to reduce tariffs and govern trade; based on MFN, national treatment, and reciprocity."
  },
  {
    front: "Most Favored Nation (MFN) Principle",
    back: "Requires trade concessions given to one WTO member be extended to all members."
  },
  {
    front: "National Treatment",
    back: "Imported goods must be treated the same as domestic goods once inside the market."
  },
  {
    front: "Uruguay Round (1986–1994)",
    back: "Landmark negotiation round that created the WTO and expanded rules to services and intellectual property."
  },
  {
    front: "WTO (World Trade Organization)",
    back: "Established in 1995; global institution governing trade rules, monitoring compliance, and resolving disputes."
  },
  {
    front: "Appellate Body (WTO)",
    back: "WTO's appeals court that reviews dispute settlement panel decisions (currently paralyzed due to U.S. objections)."
  },
  {
    front: "Dumping",
    back: "Selling exports below fair market value or below domestic price to gain market share."
  }
]

export default function Home() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)
  const [cards, setCards] = useState<Flashcard[]>(flashcards)

  const currentCard = cards[currentIndex]

  const shuffleCards = () => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5)
    setCards(shuffled)
    setCurrentIndex(0)
    setIsFlipped(false)
  }

  const nextCard = () => {
    setCurrentIndex((prev) => (prev + 1) % cards.length)
    setIsFlipped(false)
  }

  const prevCard = () => {
    setCurrentIndex((prev) => (prev - 1 + cards.length) % cards.length)
    setIsFlipped(false)
  }

  const flipCard = () => {
    setIsFlipped(!isFlipped)
  }

  const handleKeyPress = (e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowLeft':
        prevCard()
        break
      case 'ArrowRight':
        nextCard()
        break
      case ' ':
        e.preventDefault()
        flipCard()
        break
      case 'r':
        shuffleCards()
        break
    }
  }

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [currentIndex, isFlipped, cards])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-8">
          <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100 mb-2">
            Trade Policy Flashcards
          </h1>
          <p className="text-slate-600 dark:text-slate-400">
            Study international trade intervention policies and concepts
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
              Card {currentIndex + 1} of {cards.length}
            </span>
            <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
              {Math.round(((currentIndex + 1) / cards.length) * 100)}%
            </span>
          </div>
          <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / cards.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Flashcard */}
        <div className="mb-8">
          <Card className="relative h-96 cursor-pointer transition-all duration-300 hover:shadow-xl" onClick={flipCard}>
            <CardContent className="p-8 h-full flex items-center justify-center">
              <div className="relative w-full h-full">
                <div
                  className={`absolute inset-0 flex items-center justify-center p-6 transition-all duration-500 ${
                    isFlipped ? 'opacity-0 rotate-y-180' : 'opacity-100 rotate-y-0'
                  }`}
                >
                  <div className="text-center">
                    <div className="text-sm font-medium text-blue-600 dark:text-blue-400 mb-4">
                      FRONT
                    </div>
                    <p className="text-xl font-semibold text-slate-800 dark:text-slate-100 leading-relaxed">
                      {currentCard.front}
                    </p>
                  </div>
                </div>
                <div
                  className={`absolute inset-0 flex items-center justify-center p-6 transition-all duration-500 ${
                    isFlipped ? 'opacity-100 rotate-y-0' : 'opacity-0 rotate-y-180'
                  }`}
                >
                  <div className="text-center">
                    <div className="text-sm font-medium text-green-600 dark:text-green-400 mb-4">
                      BACK
                    </div>
                    <p className="text-lg text-slate-700 dark:text-slate-200 leading-relaxed">
                      {currentCard.back}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
          <Button
            variant="outline"
            size="lg"
            onClick={prevCard}
            className="flex items-center gap-2 min-w-[120px]"
          >
            <ChevronLeft className="w-5 h-5" />
            Previous
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            onClick={flipCard}
            className="flex items-center gap-2 min-w-[120px]"
          >
            <RotateCcw className="w-5 h-5" />
            Flip Card
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            onClick={nextCard}
            className="flex items-center gap-2 min-w-[120px]"
          >
            Next
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>

        {/* Shuffle Button */}
        <div className="flex justify-center mb-8">
          <Button
            variant="default"
            size="lg"
            onClick={shuffleCards}
            className="flex items-center gap-2 min-w-[150px]"
          >
            <Shuffle className="w-5 h-5" />
            Reshuffle Cards
          </Button>
        </div>

        {/* Keyboard Shortcuts */}
        <div className="text-center text-sm text-slate-500 dark:text-slate-400">
          <p className="mb-2">Keyboard shortcuts:</p>
          <div className="flex flex-wrap justify-center gap-4">
            <span>← → Navigate</span>
            <span>Space Flip</span>
            <span>R Reshuffle</span>
          </div>
        </div>
      </div>

      <style jsx>{`
        .rotate-y-180 {
          transform: rotateY(180deg);
        }
        .rotate-y-0 {
          transform: rotateY(0deg);
        }
      `}</style>
    </div>
  )
}